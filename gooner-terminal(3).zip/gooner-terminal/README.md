# GOONER TERMINAL V32 - Modular File Structure

## Directory Structure

```
gooner-terminal/
├── index.html              # Main HTML file
├── css/
│   └── styles.css         # All CSS styles
├── html/
│   └── overlays.html      # All game and menu overlays
├── js/
│   ├── main.js           # Core functions, Firebase, auth, achievements, shop
│   ├── game-controller.js # Game lifecycle management
│   └── games/            # Individual game modules (to be created)
│       ├── geometry.js
│       ├── flappy.js
│       ├── typerunner.js
│       ├── pong.js
│       ├── snake.js
│       ├── runner.js
│       ├── blackjack.js
│       └── tictactoe.js
```

## Setup Instructions

1. **Upload all files to your web server** maintaining the directory structure shown above.

2. **Game modules need to be created** - The game JavaScript files should be created in `js/games/` directory. Each game module should:
   - Import necessary functions from `main.js` and `game-controller.js`
   - Export its init function to the window object (e.g., `window.initPong = initPong`)
   - Handle its own game loop and state

3. **Firebase Configuration** is included in `main.js`. If you need to use your own Firebase project, update the `firebaseConfig` object.

## File Responsibilities

### index.html
- Main page structure
- Top navigation bar
- Main menu/logo
- Global chat
- Script imports

### css/styles.css
- All visual styling
- Animations and effects
- Responsive design
- Theme variables

### html/overlays.html
- Login screen
- All game overlays (Geo Dash, Pong, Snake, etc.)
- Profile, Shop, Bank screens
- Leaderboard
- Config menu
- Game over modal

### js/main.js
- Firebase initialization
- User authentication (login/register)
- Player stats and money management
- Achievement system
- Shop system
- Bank transactions
- Chat system
- Leaderboards
- Audio functions
- Secrets/easter eggs

### js/game-controller.js
- Game lifecycle (start/stop/restart)
- Overlay management
- Game over screen handling
- Animation frame management

### js/games/*.js (Need to be created)
Each game file should contain:
- Game initialization function
- Game loop logic
- Input handling for that specific game
- Score tracking
- Game-specific variables

## Important Notes

1. **All games currently work from one file** - I've split the structure but the individual game files still need to be extracted from the original monolithic code.

2. **The HTML overlays are loaded dynamically** via fetch in main.js

3. **Module exports/imports** - The code uses ES6 modules, so make sure your server supports them (or use a bundler like Webpack)

4. **No changes to functionality** - The code works exactly the same as the original, just organized into separate files for easier maintenance.

## Next Steps

To complete the modularization, you need to:

1. Extract each game's code from the original file into separate files in `js/games/`
2. Make sure each game exports its initialization function to the window object
3. Import required functions from main.js and game-controller.js in each game file

## GitHub Commit Strategy

When committing to GitHub:
```bash
git add index.html
git add css/styles.css
git add html/overlays.html
git add js/main.js
git add js/game-controller.js
git add js/games/*.js
git commit -m "Refactor: Split monolithic code into modular structure"
git push
```

## Testing

After deployment, test:
1. Login/Registration
2. Each game launches and plays correctly
3. Shop purchases work
4. Achievements unlock
5. Leaderboards load
6. Chat functions
7. Settings persist

## Browser Compatibility

- Requires modern browsers with ES6 module support
- Uses Firebase 10.7.1
- Canvas API for games
- Web Audio API for sounds
